﻿using System;

class Program
{
    static double GetUserInput()
    {
        double a;
        bool flag = true;
        do
        {
            var res = double.TryParse(Console.ReadLine(), out a);

            if (res == false) flag = false;
            else flag = true;
        } while (!flag);

        return a;
    }

    static double algorithm(double x, double y)
    {
        if (x > y)
            return 5 * x + y;
        else if (x == y)
            return Math.Cos(x);
        else if (((y - 10) < x) && (x < y))
            return -2 * Math.Sin(y);
        else
            return 0;
    }

    static void Main()
    {
        var x = GetUserInput();
        var y = GetUserInput();

        Console.WriteLine(algorithm(x, y));

        Console.ReadKey();
    }
}