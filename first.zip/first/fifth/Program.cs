﻿using System;

namespace fifth
{
    class Program
    {
        static double GetInput()
        {
            double a;
            bool res;
            do
            {
                res = double.TryParse(Console.ReadLine(), out a);
            } while (!res);

            return a;
        }

        static double F(double x, double y)
        {
            if (x >= y)
                return 5 * x;
            else if (x < 0)
                return -2 * x;
            else
                throw new Exception("F() can't calculate the answer for the given numbers");
        }

        static double Z(double x, double y)
        {
            return 2 * F(x, y) + 4 * F(x, y);
        }

        static void Main()
        {
            var x = GetInput();
            var y = GetInput();

            Console.WriteLine(Z(x, y));


            Console.ReadKey();
        }
    }
}
