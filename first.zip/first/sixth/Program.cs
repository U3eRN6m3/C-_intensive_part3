﻿using System;

namespace sixth
{
    class Program
    {
        static void Inc(ref int x)
        {
            x++;
        } 
        
        static void Dec(ref int y)
        {
            while (y > 0)
            {
                Console.WriteLine(y);
                y--;
            }

            y = 10;
        }

        static void Main()
        {
            int x = 0;
            Inc(ref x);
            Console.WriteLine(x);

            int y = 10;
            Dec(ref y);
            Console.WriteLine(y);

            Console.ReadKey();
        }
    }
}
