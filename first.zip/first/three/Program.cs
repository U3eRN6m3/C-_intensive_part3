﻿using System;

namespace third
{
    class Program
    {
        static double GetInput()
        {
            double a;
            bool res;
            do
            {
                res = double.TryParse(Console.ReadLine(), out a);
            } while (!res);

            return a;
        }

        static void Main()
        {
            double product = 1;
            for (var i = 0; i < 10; ++i)
                product *= GetInput();

            Console.WriteLine(Math.Pow(product, 0.1));

            Console.ReadKey();
        }
    }
}
