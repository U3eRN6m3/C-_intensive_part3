﻿using System;

namespace fourth
{
    class Program
    {
        static double GetInput()
        {
            double a;
            bool res;
            do
            {
                res = double.TryParse(Console.ReadLine(), out a);
            } while (!res);

            return a;
        }

        static double F(double a, double b)
        {
            return 2 * a + (b / 5) + Math.Sin((a + b));
        }

        static double Z(double x, double y)
        {
            return F(x, 0) + 2 * F(y, 1) + 2 * F(x, y);
        }

        static void Main()
        {
            var x = GetInput();
            var y = GetInput();

            Console.WriteLine(Z(x, y));


            Console.ReadKey();
        }
    }
}
