﻿using System;

namespace seventh
{
    class Program
    {
        static double GetInput()
        {
            double a;
            bool res;
            do
            {
                res = double.TryParse(Console.ReadLine(), out a);
            } while (!res);

            return a;
        }

        static double Add(double x, double y)
        {
            return x + y;
        }

        static double Sub(double x, double y)
        {
            return x - y;
        }

        static void Main()
        {
            var x = GetInput();
            var y = GetInput();

            Console.WriteLine(Add(x, y));
            Console.WriteLine(Sub(x, y));

            Console.ReadKey();
        }
    }
}
