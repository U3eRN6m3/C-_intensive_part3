﻿using System;

namespace second
{
    class Program
    {
        static double GetInput()
        {
            double a;
            bool res;
            do
            {
                res = double.TryParse(Console.ReadLine(), out a);
            } while (!res);

            return a;
        }

        static void Main()
        {
            double summa = 0;
            for (var i = 0; i < 10; ++i)
                summa += GetInput();

            Console.WriteLine(summa / 10);

            Console.ReadKey();
        }
    }
}
